# scansioni.ch Backend - OCR Engine

FastAPI backend con OCR integrato per immagini e PDF.